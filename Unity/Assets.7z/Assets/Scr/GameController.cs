using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameController : MonoBehaviour {

    public int whoTurn; // 0->O 1->X
    public int turnCount;
    public GameObject[] turnIcons;
    public Sprite[] playIcons;
    public Button[] tictactoeSpaces;
    public int[] markedSpaces;
    public int winner;
    public int winningConf;
    //public int[] posibleSolutions;
    public GameObject[] winningLines;
    public GameObject[] winnerText;

    void Start() {
        GameSetup();
    }

    void GameSetup() {
        whoTurn = 0;
        turnCount = 0;
        winner=-1;
        turnIcons[0].SetActive(true);
        turnIcons[1].SetActive(false);
        for(int i=0; i<tictactoeSpaces.Length; i++){
            tictactoeSpaces[i].interactable = true;
            tictactoeSpaces[i].GetComponent<Image>().sprite = null;
        }
        for(int i=0; i<markedSpaces.Length;i++){
            markedSpaces[i]=-10;
        }
        for(int i=0; i<winningLines.Length;i++){
            winningLines[i].SetActive(false);
        }
        for(int i=0; i<winnerText.Length;i++){
            winnerText[i].SetActive(false);
        }
        Debug.Log(markedSpaces);
        winningConf=-1;

    }

    void Update() {

    }

    public void TicTacToeButton(int WhichButton){
        tictactoeSpaces[WhichButton].image.sprite = playIcons[whoTurn];
        tictactoeSpaces[WhichButton].interactable = false;
        markedSpaces[WhichButton]=whoTurn;
        turnCount++;
        if(turnCount>4){
            WinnerCheck();
        }
        if(whoTurn==0){
            whoTurn = 1;
            turnIcons[0].SetActive(false);
            turnIcons[1].SetActive(true);
        }
        else{
            whoTurn = 0;
            turnIcons[0].SetActive(true);
            turnIcons[1].SetActive(false);
        }
    }

    public void WinnerCheck(){
        Debug.Log(markedSpaces);
        //poziomo
        int config1= markedSpaces[0] + markedSpaces[1] + markedSpaces[2];
        int config2 = markedSpaces[3] + markedSpaces[4] + markedSpaces[5];
        int config3 = markedSpaces[6] + markedSpaces[7] + markedSpaces[8];
        //pionowo
        int config4 = markedSpaces[0] + markedSpaces[3] + markedSpaces[6];
        int config5 = markedSpaces[1] + markedSpaces[4] + markedSpaces[7];
        int config6 = markedSpaces[2] + markedSpaces[5] + markedSpaces[8];
        //na skos
        int config7 = markedSpaces[0] + markedSpaces[4] + markedSpaces[8];
        int config8 = markedSpaces[2] + markedSpaces[4] + markedSpaces[6];

        var posibleSolutions = new int [] {config1, config2, config3, config4, config5, config6, config7, config8};
        for(int i=0; i<posibleSolutions.Length;i++){
            if(posibleSolutions[i]==0){
                winner = 0;
                winningConf=i;
                Debug.Log("Player 0 won!");
                
                winningLines[i].SetActive(true);
                winnerText[0].SetActive(true);
                for(int j=0; j<tictactoeSpaces.Length; j++){
                    tictactoeSpaces[j].interactable = false;
                }
                
            }
            if(posibleSolutions[i]==3){
                winner = 1;
                winningConf=i;
                winningLines[i].SetActive(true);
                winnerText[1].SetActive(true);
                Debug.Log("Player 1 won!");
                for(int j=0; j<tictactoeSpaces.Length; j++){
                    tictactoeSpaces[j].interactable = false;
                }
            }
        }
    }

    public void WinnerDisplay(int winningConf){

    }
}